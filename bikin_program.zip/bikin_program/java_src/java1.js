
//window.onload = function()
//{
var pos1=0; //start position
var pos2=0; //start position
var box= document.getElementById("box"); //our box element
var t= setInterval(move,20);
function move()
{
if(pos1 >= 150)
{
pos2 += 1;
box.style.left = pos2+"px"; // px = pixel
if(pos2 >= 150)
{
pos1=0;
pos2=0;
box.style.right = 0 + "px";
//box.style.left = 0 + "px";
}
}
else
{
pos1 += 1;
box.style.right = pos1+"px"; // px = pixel
}
}
//};

